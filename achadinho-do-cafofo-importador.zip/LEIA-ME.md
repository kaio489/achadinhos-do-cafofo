# Achadinho do Cafofo — preenchimento de produtos

O botão **Preencher** agora consulta o conteúdo da página, seguindo links encurtados quando a loja permite. Ele procura nome, imagem, preço, preço anterior, descrição e categoria. A descrição também aproveita características como marca, cor e avaliação, quando disponíveis. O link de afiliado digitado é mantido no produto.

## Publicar na Vercel

1. Extraia o ZIP e coloque **todos os arquivos desta pasta** na raiz do repositório do site no GitHub. Inclua `index.html`, as pastas `api` e `lib`, `package.json`, `package-lock.json`, `build.mjs` e `vercel.json`.
2. Faça o commit e aguarde a Vercel publicar a nova versão. Se estiver criando um projeto, escolha o preset **Other**. O arquivo `vercel.json` já define o build e a saída `public`.
3. Abra o site publicado, entre no painel, cole o link e clique em **Preencher**. Confira a prévia e os campos antes de adicionar o produto.
4. Ao cadastrar produtos, continue usando **Baixar site atualizado** e substitua o `index.html` na raiz do repositório. Mantenha os demais arquivos: eles fazem a importação funcionar.

Somente trocar o HTML não instala a consulta automática. O HTML pode ser aberto sozinho no computador para navegar e usar a captura manual descrita abaixo.

## Quando o Mercado Livre ou outra loja bloqueia

Nem toda página libera uma consulta automática. Login, verificação de acesso, limites da loja e conteúdo carregado depois da abertura podem impedir a leitura. Não há garantia de importar todos os links.

O link `https://meli.la/1P3Kgkz` retornou **403** na consulta feita durante esta edição. Portanto, não foi possível confirmar uma importação automática ao vivo desse link. Os testes do preenchimento usaram páginas de teste com a estrutura de produto, incluindo nome, R$ 67,85 e preço anterior R$ 78,90 da imagem enviada. Esses valores não foram fixados no site nem cadastrados como um novo produto.

Use a seção **A loja bloqueou a consulta? Capture pela página aberta** no painel:

1. No computador, mostre a barra de favoritos com **Ctrl + Shift + B**.
2. Arraste o botão **Capturar achadinho** do painel para a barra de favoritos.
3. Abra o produto na loja e espere carregar. Selecione a variação desejada e clique no favorito **Capturar achadinho**.
4. Os dados serão copiados. Se o navegador não permitir a cópia direta, aparecerá uma caixa para copiar o texto.
5. Volte ao painel, cole o conteúdo no campo de captura e clique em **Ler dados colados**.

O favorito lê os dados disponíveis na página que você abriu e copia o resultado. Também é possível colar o código HTML de uma página salva. Essa captura não executa scripts do HTML colado. Alguns navegadores ou lojas podem restringir o favorito; nesses casos, complete os campos restantes manualmente.

## Informações importantes para conferir

- Preços são uma consulta pontual. Podem mudar depois, variar por cor/modelo ou depender de assinatura, cupom, frete ou localização. O importador não faz atualização contínua de preços.
- Um preço de outra moeda não é convertido automaticamente para reais.
- A foto depende do endereço disponibilizado pela loja. Se ela não abrir, envie uma imagem pelo próprio painel.
- Os dados não encontrados ficam para conferência, sem inventar preço ou imagem.
- O serviço consulta apenas os domínios de lojas permitidos e seus redirecionamentos. Não usa serviços públicos de proxy.
- O painel e os dados continuam com o armazenamento local que já existia no site. Este pacote não adiciona banco de dados ou autenticação de servidor.

## API oficial do Mercado Livre (opcional)

O serviço também tenta a API de itens quando encontra um ID de anúncio compatível. Se você já tiver um token válido e autorizado, pode definir `MERCADO_LIVRE_ACCESS_TOKEN` nas variáveis de ambiente da Vercel e republicar. O token fica somente no servidor. Sua existência não garante acesso a todo anúncio. Não coloque tokens no HTML.

## Testar no computador com o serviço

Com Node.js 22 instalado, execute `npm install` e `npm run dev`. Abra `http://localhost:8766`. A captura por favorito funciona também sem esse serviço.

## Referências técnicas

- Vercel Functions: https://vercel.com/docs/functions/runtimes/node-js
- Restrições de leitura entre sites: https://developer.mozilla.org/pt-BR/docs/Web/HTTP/Guides/CORS
- API de itens Mercado Livre: https://developers.mercadolivre.com.br/pt_br/itens-e-buscas
