import {importProduct} from '../lib/import-product.mjs';
const visits=new Map();
export default async function handler(req,res){
 res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
 const send=(status,data)=>{res.statusCode=status;res.end(JSON.stringify(data))};
 if(req.method!=='POST'){res.setHeader('Allow','POST');return send(405,{error:'METHOD_NOT_ALLOWED',message:'Use POST para consultar o produto.'})}
 if(req.headers.origin){try{if(new URL(req.headers.origin).host!==req.headers.host)return send(403,{error:'ORIGIN_NOT_ALLOWED',message:'Abra o painel no próprio site.'})}catch{return send(403,{error:'ORIGIN_NOT_ALLOWED',message:'Origem inválida.'})}}
 const ip=String(req.headers['x-forwarded-for']||req.socket?.remoteAddress||'local').split(',')[0];const now=Date.now();
 if(visits.size>2000)for(const [key,v]of visits)if(now-v.start>60000)visits.delete(key);
 let quota=visits.get(ip);if(!quota||now-quota.start>60000){quota={start:now,n:0};visits.set(ip,quota)}if(++quota.n>20){res.setHeader('Retry-After','60');return send(429,{error:'RATE_LIMIT',message:'Muitas consultas. Aguarde um minuto e tente novamente.'})}
 if(!String(req.headers['content-type']||'').includes('application/json'))return send(415,{error:'INVALID_BODY',message:'Envie o link em JSON.'});
 try{
  const body=typeof req.body==='string'?JSON.parse(req.body):req.body;
  if(!body||typeof body.url!=='string'||body.url.length>3000)return send(400,{error:'INVALID_URL',message:'Informe um link de produto válido.'});
  const data=await importProduct(body.url,{signal:AbortSignal.timeout(22000)});return send(200,data);
 }catch(e){const bad=['INVALID_URL','UNSUPPORTED_URL'].includes(e.message);return send(bad?400:422,{error:bad?e.message:'IMPORT_UNAVAILABLE',message:bad?'Use um link HTTPS de Mercado Livre, Shopee, Amazon, AliExpress ou Magalu.':'A loja não liberou os dados desta página. Use a captura pela página aberta para importar, ou preencha os campos que faltam.'})}
}
