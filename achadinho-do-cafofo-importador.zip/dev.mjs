import http from 'node:http';
import {readFile} from 'node:fs/promises';
import handler from './api/product.js';
http.createServer(async(req,res)=>{
 if(req.url==='/api/product'){
  let body='';for await(const chunk of req){body+=chunk;if(body.length>5000){res.writeHead(413);return res.end('Too large')}}
  try{req.body=JSON.parse(body)}catch{}return handler(req,res);
 }
 if(req.url==='/'||req.url==='/index.html'){res.setHeader('Content-Type','text/html; charset=utf-8');return res.end(await readFile(new URL('./index.html',import.meta.url)))}
 res.writeHead(404);res.end('Not found');
}).listen(process.env.PORT||8766,'127.0.0.1',()=>console.log('Abra http://localhost:'+(process.env.PORT||8766)));
